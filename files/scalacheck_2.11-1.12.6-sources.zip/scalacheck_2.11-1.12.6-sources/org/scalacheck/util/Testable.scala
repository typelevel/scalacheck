package org.scalacheck.util

// TODO: Just kept for binary compatibility. Remove it in 1.13.0

/** Marks a type as testable. This is not used anywhere, and will be removed in
 *  ScalaCheck 1.13.0. */
trait Testable { }
