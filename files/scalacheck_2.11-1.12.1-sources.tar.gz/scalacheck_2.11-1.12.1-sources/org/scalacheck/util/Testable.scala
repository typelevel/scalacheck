package org.scalacheck.util

/** Marks a type as testable */
trait Testable { }
